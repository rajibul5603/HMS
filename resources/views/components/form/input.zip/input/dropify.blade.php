<div>
    <div class="form-group">
        <label for="{{$id ?? ''}}">{{$label ?? ''}}</label>
        <input type="file" class="dropify" data-default-file="{{$default ?? ''}}" data-height="190" id="{{$id ?? ''}}" name="{{$id ?? ''}}" />
      </div>
</div>
